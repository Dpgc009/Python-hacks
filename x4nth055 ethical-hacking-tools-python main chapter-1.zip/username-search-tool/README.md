## Steps to Use Sherlock Username Search Tool
- `$ pip install sherlock-project`
- `$ sherlock exampleuser1 exampleuser2`